# Project HTML-203-01
- [FreecodeCamp Challenge](https://www.freecodecamp.org/learn/2022/responsive-web-design/learn-html-by-building-a-cat-photo-app/step-1)
This is your assignment 3, where you have to make use of all the elements you have learnt and create cat photo app

# Photo Cat App HTML-203-02

## Preview
![image](./Images/Screenshot%202022-09-17%20at%2012.29.17%20PM.png)

## Points to Remember
- Create the above website using HTML only in ```index.html``` inside ```Cat App``` folder
- Host the website and provide the link in this README file
- https://roshansah1.github.io/WebAssignment/2-HTML/203-HTML-Photo-Cat-App/HTML-203-01-CatApp/
