# Assignment HTML-201-01
This is your assignment 1, where you have to make your resume

## End Project view
![resume](./Images/resume.png)
![resume2](./Images/resume2.png)


## Points to Remember
- Create index.html file in ```./Resume``` folder
- Create the above resume using HTML only
- Host the Resume and provide the link in this README file 
- https://roshansah1.github.io/WebAssignment/2-HTML/201-HTML-RESUME/HTML-201-01/

